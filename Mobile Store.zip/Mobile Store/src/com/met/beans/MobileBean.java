/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.beans;
/**
 *
 * @author BackAgaIN
 */
import java.io.Serializable;

public class MobileBean implements Serializable{
    
    private int id;
    private String mname;
    private String mram;
    private String mrom;
    private String mcolor;
    private String myear;
    private String mstock;
    private String mcompany;
    private int mprice;

    public String getMcompany() {
        return mcompany;
    }

    public void setMcompany(String mcompany) {
        this.mcompany = mcompany;
    }
    
    public String getColor() {
        return mcolor;
    }

    public void setColor(String mcolor) {
        this.mcolor = mcolor;
    }

    public String getYear() {
        return myear;
    }

    public void setYear(String myear) {
        this.myear = myear;
    }

    public String getStock() {
        return mstock;
    }

    public void setStock(String mstock) {
        this.mstock = mstock;
    }

    public int getPrice() {
        return mprice;
    }

    public void setPrice(int mprice) {
        this.mprice = mprice;
    }
    
    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getMram() {
        return mram;
    }

    public void setMram(String mram) {
        this.mram = mram;
    }

    public String getMrom() {
        return mrom;
    }

    public void setMrom(String mrom) {
        this.mrom = mrom;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
}
