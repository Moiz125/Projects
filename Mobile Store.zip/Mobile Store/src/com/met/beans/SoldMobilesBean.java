/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.beans;

import java.io.Serializable;

/**
 *
 * @author BackAgaIN
 */
public class SoldMobilesBean implements Serializable{
        
        private int id;
        private String mname;
        private String cname;
        private String ccnic;
        private String solddate;
        private int soldprice;

    public int getSoldprice() {
        return soldprice;
    }

    public void setSoldprice(int soldprice) {
        this.soldprice = soldprice;
    }
        

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCcnic() {
        return ccnic;
    }

    public void setCcnic(String ccnic) {
        this.ccnic = ccnic;
    }

    public String getSolddate() {
        return solddate;
    }

    public void setSolddate(String solddate) {
        this.solddate = solddate;
    }


}
