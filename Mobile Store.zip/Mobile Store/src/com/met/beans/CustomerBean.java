/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.beans;

import java.io.Serializable;

/**
 *
 * @author BackAgaIN
 */
public class CustomerBean implements Serializable{
    
    private String cname;
    private String ccnic;
    private String cphone;
    private String caddress;
    private String pay_type;
    private String ccard;
    
    public String getPay_type() {
        return pay_type;
    }

    public void setPay_type(String pay_type) {
        this.pay_type = pay_type;
    }
    
    public String getCphone() {
        return cphone;
    }

    public void setCphone(String cphone) {
        this.cphone = cphone;
    }

    public String getCaddress() {
        return caddress;
    }

    public void setCaddress(String caddress) {
        this.caddress = caddress;
    }
    
    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCcnic() {
        return ccnic;
    }

    public void setCcnic(String ccnic) {
        this.ccnic = ccnic;
    }
    
    public String getCcard() {
        return ccard;
    }

    public void setCcard(String ccard) {
        this.ccard = ccard;
    }
    
    
}
