/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.connection;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author  BackAgaIN
 */
public class DBConnection {
    private DBConnection()
    {
    }
    
        private static Connection conn = null;
        public static Connection createConnection()
        {
            if(conn==null)
            {
                try
                {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mobiles","root","Patujo2000");
                }catch(Exception e){}
            }
            return conn;
        }
        
}
