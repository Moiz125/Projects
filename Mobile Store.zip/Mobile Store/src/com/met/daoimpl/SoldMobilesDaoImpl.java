/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.daoimpl;

import com.met.beans.SoldMobilesBean;
import com.met.connection.DBConnection;
import com.met.dao.SoldMobilesDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author BackAgaIN
 */
public class SoldMobilesDaoImpl implements SoldMobilesDao{
    
    private static final Connection conn = DBConnection.createConnection();
    private PreparedStatement stmt;
    private ResultSet rs;
    @Override
    public List<SoldMobilesBean> getAllSoldMobiles() 
    {
        SoldMobilesBean smb;
        List<SoldMobilesBean> lsmb = new ArrayList();
        try
        {
            smb = new SoldMobilesBean();
            stmt = conn.prepareStatement("Select * from soldmobilesinfo");
            rs = stmt.executeQuery();
            while(rs.next())
            {
                smb.setId(rs.getInt("m_id"));
                smb.setMname(rs.getString("m_name"));
                smb.setCname(rs.getString("c_name"));
                smb.setCcnic(rs.getString("c_cinc"));
                smb.setSolddate(rs.getString("sold_date"));
                
            }
        }
        catch(SQLException sql){}
        return lsmb;
        
    }

    @Override
    public int addSoldMobile(SoldMobilesBean smb) {
        try
        {
           stmt = conn.prepareStatement("Insert into soldmobilesinfo(fk_m_id,sm_name,smc_name,fk_c_cnic,sold_date,sm_price)"+"values(?,?,?,?,?,?)");
           stmt.setInt(1,smb.getId());
           stmt.setString(2,smb.getMname());
           stmt.setString(3,smb.getCname());
           stmt.setString(4,smb.getCcnic());
           stmt.setString(5,smb.getSolddate());
           stmt.setInt(6,smb.getSoldprice());
           stmt.executeUpdate();
           stmt = conn.prepareStatement("Update mobileinfo SET m_stock ='Sold' where m_id='"+smb.getId()+"'");
           return stmt.executeUpdate();
        }
        catch(SQLException sql)
        {
            System.out.println(sql);
        }
        
        return 0;
    }

    @Override
    public int checkDiscount(SoldMobilesBean smb,int x) {
        int count=0;
        try{
            String s="Select smc_name from soldmobilesinfo where fk_c_cnic='"+smb.getCcnic()+"'";
            
            Statement st;
            st=conn.createStatement();
            rs = st.executeQuery(s);
            while(rs.next())
            {
                count++;
            }
        }catch(Exception e){
                System.out.println("Error in cnic: "+e.getMessage());
            }
        System.out.println(count);
        if(count==1)
        {
            JOptionPane.showMessageDialog(null,"You have avaliled 2% discount.Your new price is: "+(x-((x*2)/100)));
            return x-((x*2)/100);
        }
        else if(count==2)
        {
            JOptionPane.showMessageDialog(null,"You have avaliled 4% discount.Your new price is: "+(x-((x*4)/100)));
            return x-((x*4)/100);
        }
        else if(count==3)
        {
            JOptionPane.showMessageDialog(null,"You have avaliled 6% discount.Your new price is: "+(x-((x*6)/100)));
            return x-((x*6)/100);
        }
        else if(count==4)
        {
            JOptionPane.showMessageDialog(null,"You have avaliled 8% discount.Your new price is: "+(x-((x*8)/100)));
            return x-((x*8)/100);
        }
        else if(count>=5)
        {
            JOptionPane.showMessageDialog(null,"You have avaliled 10% discount.Your new price is: "+(x-((x*10)/100)));
            return x-((x*10)/100);
        }
        return x;
    }
        
        
}
