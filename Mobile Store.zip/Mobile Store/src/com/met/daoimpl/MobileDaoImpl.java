/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.daoimpl;

import com.met.beans.MobileBean;
import com.met.connection.DBConnection;
import com.met.dao.MobileDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author BackAgaIN
 */
public class MobileDaoImpl implements MobileDao {
    
    private static final Connection conn = DBConnection.createConnection();
    private static PreparedStatement stmt;
    ResultSet rs;
    private MobileBean mb;
    @Override
    public  Stack<MobileBean> getAllMobiles(String input) {
        
        Stack<MobileBean> smb = new Stack();
        try{
            stmt = conn.prepareStatement("Select * from mobileinfo where m_stock IN('"+input+"')");
            rs = stmt.executeQuery();
            while(rs.next()){
                mb = new MobileBean();
                mb.setId(rs.getInt("m_id"));
                mb.setMname(rs.getString("m_name"));
                mb.setMram(rs.getString("m_ram"));
                mb.setMrom(rs.getString("m_rom"));
                mb.setColor(rs.getString("m_color"));
                mb.setYear(rs.getString("m_year"));
                mb.setStock(rs.getString("m_stock"));
                mb.setPrice(rs.getInt("m_price"));
                mb.setMcompany(rs.getString("m_company"));
                smb.push(mb);
            }
        }
        catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        return smb;
    }

    @Override
    public int addMobile(MobileBean mobile) {
        try
        {
            stmt = conn.prepareStatement("Insert into mobileinfo(m_name,m_ram,m_rom,m_color,m_year,m_stock,m_price,m_company)"+"value(?,?,?,?,?,?,?,?)");
            stmt.setString(1,mobile.getMname());
            stmt.setString(2,mobile.getMram());
            stmt.setString(3,mobile.getMrom());
            stmt.setString(4,mobile.getColor());
            stmt.setString(5,mobile.getYear());
            stmt.setString(6,mobile.getStock());
            stmt.setInt(7,mobile.getPrice());
            stmt.setString(8,mobile.getMcompany());
            return stmt.executeUpdate();
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        return 0;
    }

    @Override
    public int removeMobile(MobileBean mobile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Stack<MobileBean> sortAZ() {

        Stack<MobileBean> smb = new Stack();
        try
        {
            stmt = conn.prepareStatement("Select * from mobileinfo order by m_name DESC");
            rs = stmt.executeQuery();
            while(rs.next()){
                mb = new MobileBean();
                mb.setId(rs.getInt("m_id"));
                mb.setMname(rs.getString("m_name"));
                mb.setMram(rs.getString("m_ram"));
                mb.setMrom(rs.getString("m_rom"));
                mb.setColor(rs.getString("m_color"));
                mb.setYear(rs.getString("m_year"));
                mb.setStock(rs.getString("m_stock"));
                mb.setPrice(rs.getInt("m_price"));
                mb.setMcompany(rs.getString("m_company"));
                smb.push(mb);
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        return smb;
    }

    @Override
    public Stack<MobileBean> sortPrice(String input) {
        
        Stack<MobileBean> smb = new Stack();
        try
        {
            stmt = conn.prepareStatement("Select * from mobileinfo order by m_price "+input+"");
            rs = stmt.executeQuery();
            while(rs.next()){
                mb = new MobileBean();
                mb.setId(rs.getInt("m_id"));
                mb.setMname(rs.getString("m_name"));
                mb.setMram(rs.getString("m_ram"));
                mb.setMrom(rs.getString("m_rom"));
                mb.setColor(rs.getString("m_color"));
                mb.setYear(rs.getString("m_year"));
                mb.setStock(rs.getString("m_Stock"));
                mb.setPrice(rs.getInt("m_price"));
                mb.setMcompany(rs.getString("m_company"));
                smb.push(mb);
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        return smb;
    }
    
    
    
}
