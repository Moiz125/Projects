/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.daoimpl;

import com.met.beans.CustomerBean;
import com.met.connection.DBConnection;
import com.met.dao.CustomerDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Stack;

/**
 *
 * @author BackAgaIN
 */
public class CustomerDaoImpl implements CustomerDao{
    
    private static final Connection conn = DBConnection.createConnection();
    private PreparedStatement stmt;
    private ResultSet rs;
    @Override
    public Stack<CustomerBean> getAllCustomers() 
    {
        CustomerBean cb;
        Stack<CustomerBean>  lcb= new Stack();
        try
        {
            stmt = conn.prepareStatement("Select * from customerinfo");
            rs = stmt.executeQuery();
            while(rs.next())
            {
                cb = new CustomerBean();
                cb.setCcnic(rs.getString("c_cnic"));
                cb.setCname(rs.getString("c_name"));
                cb.setCcard(rs.getString("c_card"));
                cb.setCphone(rs.getString("c_phone"));
                cb.setCaddress(rs.getString("c_address"));
                cb.setPay_type(rs.getString("pay_type"));
                lcb.push(cb);
            }
        }
        catch(SQLException sql)
        {}
        return lcb;
    }

    @Override
    public int addCustomer(CustomerBean cust) {
        try
        {
           stmt = conn.prepareStatement("Insert into customerinfo(c_cnic,c_name,c_card,c_phone,c_address,pay_type)"+"values(?,?,?,?,?,?)");
           stmt.setString(1,cust.getCcnic());
           stmt.setString(2,cust.getCname());
           stmt.setString(3,cust.getCcard());
           stmt.setString(4,cust.getCphone());
           stmt.setString(5,cust.getCaddress());
           stmt.setString(6,cust.getPay_type());
           return stmt.executeUpdate();
        }
        catch(SQLException sql)
        {
            System.out.println(sql);
        }
        return 0;
    }

    
}   
