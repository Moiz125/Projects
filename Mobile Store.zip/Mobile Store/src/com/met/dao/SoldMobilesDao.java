/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.dao;

import com.met.beans.SoldMobilesBean;
import java.util.List;

/**
 *
 * @author BackAgaIN
 */
public interface SoldMobilesDao{
    
         public List<SoldMobilesBean> getAllSoldMobiles();
         public int addSoldMobile(SoldMobilesBean smb);
         public int checkDiscount(SoldMobilesBean smb,int x);
}
