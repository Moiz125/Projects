/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.met.dao;

import com.met.beans.MobileBean;
import java.util.Stack;

/**
 *
 * @author BackAgaIN
 */
public interface MobileDao {
    
    public Stack<MobileBean> getAllMobiles(String input);
    public int addMobile(MobileBean mobile);
    public int removeMobile(MobileBean mobile);
    public Stack<MobileBean> sortAZ();
    public Stack<MobileBean> sortPrice(String input);
    
}
